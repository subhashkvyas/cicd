package com.example.demo_cicd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCicdApplicationTests {

	@Test
	void contextLoads() {
	}

}
